// Constants
const CONTACT_PHONE = '5511973875404';

// Functions exposed to global scope
window.scrollToSection = (id) => {
  const element = document.getElementById(id);
  const mobileMenu = document.getElementById('mobile-menu');
  
  // Close mobile menu
  if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
    mobileMenu.classList.add('hidden');
    const iconMenu = document.getElementById('icon-menu');
    const iconClose = document.getElementById('icon-close');
    if (iconMenu && iconClose) {
      iconMenu.classList.remove('hidden');
      iconClose.classList.add('hidden');
    }
  }

  if (element) {
    const headerOffset = 80;
    const elementPosition = element.getBoundingClientRect().top;
    const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
    window.scrollTo({
      top: offsetPosition,
      behavior: 'smooth'
    });
  }
};

window.scrollToTop = () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

window.openWhatsApp = (serviceTitle) => {
  const message = encodeURIComponent(
    serviceTitle 
      ? `Olá, gostaria de agendar uma sessão de ${serviceTitle}.`
      : "Olá, gostaria de agendar uma sessão."
  );
  window.open(`https://wa.me/${CONTACT_PHONE}?text=${message}`, '_blank');
};

// Initialization
document.addEventListener('DOMContentLoaded', () => {
  // Set Year
  const yearElement = document.getElementById('year');
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear().toString();
  }

  // Header Scroll Effect
  const header = document.getElementById('main-header');
  const logo = document.getElementById('header-logo');
  const brandText = document.getElementById('brand-text');
  const headerBtn = document.getElementById('header-btn');
  const navLinks = document.querySelectorAll('.nav-link');
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  const iconMenu = document.getElementById('icon-menu');
  const iconClose = document.getElementById('icon-close');

  const handleScroll = () => {
    const isScrolled = window.scrollY > 50;

    if (header) {
      if (isScrolled) {
        header.classList.remove('bg-transparent', 'py-4');
        header.classList.add('bg-white/95', 'backdrop-blur-md', 'shadow-md', 'py-3');
      } else {
        header.classList.add('bg-transparent', 'py-4');
        header.classList.remove('bg-white/95', 'backdrop-blur-md', 'shadow-md', 'py-3');
      }
    }

    if (logo) {
      if (isScrolled) {
        logo.classList.remove('opacity-90');
        logo.classList.add('opacity-100');
      } else {
        logo.classList.add('opacity-90');
        logo.classList.remove('opacity-100');
      }
    }

    if (brandText) {
      const title = brandText.querySelector('span:first-child');
      const subtitle = brandText.querySelector('span:last-child');
      
      if (isScrolled) {
        brandText.classList.remove('text-white');
        brandText.classList.add('text-gold');
        if (subtitle) {
          subtitle.classList.remove('text-white/80');
          subtitle.classList.add('text-gray-500');
        }
      } else {
        brandText.classList.add('text-white');
        brandText.classList.remove('text-gold');
        if (subtitle) {
          subtitle.classList.add('text-white/80');
          subtitle.classList.remove('text-gray-500');
        }
      }
    }
    
    // Update Header Button
    if (headerBtn) {
      if (isScrolled) {
        // Scrolled state
        headerBtn.classList.remove('bg-gradient-to-r', 'from-white', 'via-gray-50', 'to-gray-100', '!text-malva', 'border-white/50', 'hover:border-white');
        headerBtn.classList.add('bg-gradient-to-r', 'from-malva', 'to-purple-500', 'text-white', 'hover:brightness-110');
      } else {
        // Transparent state
        headerBtn.classList.add('bg-gradient-to-r', 'from-white', 'via-gray-50', 'to-gray-100', '!text-malva', 'border-white/50', 'hover:border-white');
        headerBtn.classList.remove('bg-gradient-to-r', 'from-malva', 'to-purple-500', 'text-white', 'hover:brightness-110');
      }
    }

    // Update Nav Links
    navLinks.forEach(link => {
       if (isScrolled) {
         link.classList.remove('text-white');
         link.classList.add('text-gray-800');
       } else {
         link.classList.add('text-white');
         link.classList.remove('text-gray-800');
       }
    });
    
    // Update Mobile Menu Button
    if (mobileMenuBtn) {
      if (isScrolled) {
        mobileMenuBtn.classList.remove('text-white');
        mobileMenuBtn.classList.add('text-gray-800');
      } else {
        mobileMenuBtn.classList.add('text-white');
        mobileMenuBtn.classList.remove('text-gray-800');
      }
    }

    // Active Section Highlight
    const sections = ['home', 'manifesto', 'services', 'benefits', 'contact'];
    const scrollPosition = window.scrollY + 150;
    
    let activeId = 'home';
    for (let i = sections.length - 1; i >= 0; i--) {
      const section = document.getElementById(sections[i]);
      if (section && section.offsetTop <= scrollPosition) {
        activeId = sections[i] === 'manifesto' ? 'home' : sections[i];
        break;
      }
    }
    
    // Default to home at top
    if (window.scrollY < 100) {
      activeId = 'home';
    }

    navLinks.forEach(link => {
      const sectionId = link.getAttribute('data-section');
      const span = link.querySelector('span.absolute');
      
      // Remove existing indicator
      if (span) span.remove();
      
      if (sectionId === activeId) {
        link.classList.add('text-gold');
        if (isScrolled) {
           link.classList.remove('text-gray-800');
        } else {
           link.classList.remove('text-white');
        }
        
        // Add indicator
        const indicator = document.createElement('span');
        indicator.className = 'absolute -bottom-1 left-0 right-0 h-0.5 bg-gold';
        link.appendChild(indicator);
      } else {
        link.classList.remove('text-gold');
        // Re-apply base color based on scroll
        if (isScrolled) {
           link.classList.add('text-gray-800');
        } else {
           link.classList.add('text-white');
        }
      }
    });
  };

  window.addEventListener('scroll', handleScroll);
  handleScroll(); // Initial check

  // Mobile Menu Toggle
  if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener('click', () => {
      const isHidden = mobileMenu.classList.contains('hidden');
      if (isHidden) {
        mobileMenu.classList.remove('hidden');
        if (iconMenu) iconMenu.classList.add('hidden');
        if (iconClose) iconClose.classList.remove('hidden');
      } else {
        mobileMenu.classList.add('hidden');
        if (iconMenu) iconMenu.classList.remove('hidden');
        if (iconClose) iconClose.classList.add('hidden');
      }
    });
  }
});
